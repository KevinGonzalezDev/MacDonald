<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Mail\DatosIngreso;

class GeneralController extends Controller
{
  public function enviocorreo(){
      $respuesta = request()->get('aid');

      Mail::to('juanario1997@gmail.com')->send(
        new DatosIngreso('hola')
      );

    }
}
