var aid = "nada"

function envioCorreo(){
  alert( 'entro' );
    $.ajax({
       url: "enviocorreo",
       headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
       type: "post",
       data: {'aid' : aid} ,
       success: function (response) {
         alert("exito");
          // You will get response from your PHP page (what you echo or print)
       },
       error: function(jqXHR, textStatus, errorThrown) {
          alert(errorThrown);
       }
   });
}
