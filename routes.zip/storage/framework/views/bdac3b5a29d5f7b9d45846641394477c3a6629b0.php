<style>
  body{
    font-family: Arial, Helvetica, sans-serif;
  }

</style>

<p> <?php echo e($mensaje); ?> </p>
<?php /**PATH C:\Users\juana\Documents\xampp\htdocs\McDonald\resources\views/emails/correo_ingreso.blade.php ENDPATH**/ ?>