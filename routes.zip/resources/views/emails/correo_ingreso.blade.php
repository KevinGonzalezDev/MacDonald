<style>
  body{
    font-family: Arial, Helvetica, sans-serif;
  }

</style>

<p> {{$mensaje}} </p>
